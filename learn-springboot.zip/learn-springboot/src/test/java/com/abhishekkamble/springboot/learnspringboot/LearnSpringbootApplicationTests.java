package com.abhishekkamble.springboot.learnspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
